
📥 Dataset Download Instructions – Skin Cancer Detection Project

To manually download and set up the dataset for this project, follow these steps:

1. Go to the official ISIC Archive website: https://www.isic-archive.com/
2. Click on the “Download” section from the top navigation.
3. Select the “ISIC 2019 Challenge Dataset” (or the dataset you wish to use).
4. Sign in or create an account if required.
5. Download the dataset ZIP file (images and metadata).
6. After download, extract all contents into a folder named **`data`** inside your project directory.
   - Suggested structure: `project_root/data/class_name/image.jpg`
   - Example: `Skin_Cancer_Detection_Project_Final/data/melanoma/img_001.jpg`
7. Ensure your dataset is organized by class folders (e.g., melanoma, nevus, benign keratosis).

⚠️ Important Notes:
- Images should be resized to **224x224** pixels before training.
- Modify the `main.py` code paths accordingly to point to your local `data/` folder.

If you have any issues or need support, feel free to reach out at: **vyshnavigajjela246@gmail.com**
