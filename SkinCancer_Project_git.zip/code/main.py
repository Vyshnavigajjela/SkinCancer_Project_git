
# main.py
# Skin Cancer Detection Using Attention-Enhanced EfficientNet

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Input, Multiply
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import classification_report, confusion_matrix

# Custom attention layer
def attention_block(inputs):
    channels = inputs.shape[-1]
    avg_pool = tf.reduce_mean(inputs, axis=[1, 2], keepdims=True)
    dense_1 = tf.keras.layers.Dense(units=channels//8, activation='relu')(avg_pool)
    dense_2 = tf.keras.layers.Dense(units=channels, activation='sigmoid')(dense_1)
    attention = Multiply()([inputs, dense_2])
    return attention

# Image size and batch
IMAGE_SIZE = [224, 224]
BATCH_SIZE = 32

# Dataset directory setup (user to manually place data)
train_dir = "dataset/train"
val_dir = "dataset/val"

# Data augmentation
train_datagen = ImageDataGenerator(rescale=1./255,
                                   rotation_range=30,
                                   horizontal_flip=True,
                                   zoom_range=0.2)

val_datagen = ImageDataGenerator(rescale=1./255)

train_data = train_datagen.flow_from_directory(train_dir,
                                               target_size=IMAGE_SIZE,
                                               batch_size=BATCH_SIZE,
                                               class_mode='binary')

val_data = val_datagen.flow_from_directory(val_dir,
                                           target_size=IMAGE_SIZE,
                                           batch_size=BATCH_SIZE,
                                           class_mode='binary')

# Base model
base_model = EfficientNetB0(include_top=False, input_shape=(224, 224, 3), weights='imagenet')
base_model.trainable = False

# Attention-enhanced model
inputs = Input(shape=(224, 224, 3))
x = base_model(inputs, training=False)
x = attention_block(x)
x = GlobalAveragePooling2D()(x)
x = Dense(128, activation='relu')(x)
outputs = Dense(1, activation='sigmoid')(x)
model = Model(inputs, outputs)

# Compile model
model.compile(optimizer=Adam(learning_rate=0.0001),
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Train the model
history = model.fit(train_data,
                    validation_data=val_data,
                    epochs=10)

# Save model
model.save("skin_cancer_model.h5")

# Evaluate and show confusion matrix
val_data.reset()
predictions = model.predict(val_data)
predictions = np.where(predictions > 0.5, 1, 0)

print(confusion_matrix(val_data.classes, predictions))
print(classification_report(val_data.classes, predictions))
